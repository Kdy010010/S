
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const dataDir = path.join(__dirname, 'data');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

app.get('/', (req, res) => {
    fs.readdir(dataDir, (err, files) => {
        if (err) {
            res.status(500).send('Error reading documents');
            return;
        }
        const documents = files.map(file => path.basename(file, '.html'));
        res.render('index', { documents });
    });
});

app.get('/view/:title', (req, res) => {
    const title = req.params.title;
    const filePath = path.join(dataDir, `${title}.html`);

    fs.readFile(filePath, 'utf8', (err, content) => {
        if (err) {
            res.status(404).send('Document not found');
            return;
        }
        res.render('view', { title, content });
    });
});

app.get('/create', (req, res) => {
    res.render('edit', { title: '', content: '' });
});

app.get('/edit/:title', (req, res) => {
    const title = req.params.title;
    const filePath = path.join(dataDir, `${title}.html`);

    fs.readFile(filePath, 'utf8', (err, content) => {
        if (err) {
            res.status(404).send('Document not found');
            return;
        }
        res.render('edit', { title, content });
    });
});

app.post('/save', (req, res) => {
    const { title, content } = req.body;
    const filePath = path.join(dataDir, `${title}.html`);

    fs.writeFile(filePath, content, (err) => {
        if (err) {
            res.status(500).send('Error saving document');
            return;
        }
        res.redirect(`/view/${title}`);
    });
});

app.post('/delete/:title', (req, res) => {
    const title = req.params.title;
    const filePath = path.join(dataDir, `${title}.html`);

    fs.unlink(filePath, (err) => {
        if (err) {
            res.status(500).send('Error deleting document');
            return;
        }
        res.redirect('/');
    });
});

app.get('/search', (req, res) => {
    const query = req.query.q.toLowerCase();
    fs.readdir(dataDir, (err, files) => {
        if (err) {
            res.status(500).send('Error reading documents');
            return;
        }
        const matchedDocuments = files.filter(file => file.toLowerCase().includes(query))
                                      .map(file => path.basename(file, '.html'));
        res.render('index', { documents: matchedDocuments });
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`kwiki server running on http://localhost:${PORT}`);
});
